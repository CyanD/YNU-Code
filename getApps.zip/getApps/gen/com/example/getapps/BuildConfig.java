/** Automatically generated file. DO NOT MODIFY */
package com.example.getapps;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}