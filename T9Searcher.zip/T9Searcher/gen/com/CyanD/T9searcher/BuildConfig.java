/** Automatically generated file. DO NOT MODIFY */
package com.CyanD.T9searcher;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}